from django.contrib import admin
from .models.usuarios import usuarios

admin.site.register(usuarios)